# Dragon's Heir (Svelte)

RPG de exploração e batalha por turnos, convertido do protótipo HTML/CSS/JS para Svelte + Vite.

## Como rodar

```bash
npm install
npm run dev      # abre em http://localhost:5173
npm run build    # gera a pasta dist/ para entrega
```

## Estrutura

```
src/
  main.js                 entrada (monta o App)
  App.svelte              troca entre as telas (menu / sobre / jogo)
  app.css                 o mesmo style.css do protótipo
  lib/
    data.js               mapa, inimigos, chefe (dados puros)
    store.js              estado do jogo (stores) + regras: mover, atacar, curar, level up
  components/
    Menu, About           telas iniciais
    Game                  tela do jogo (monta os componentes abaixo + teclado)
    HeroHud, EnemyHud     painéis de status
    MapGrid               mapa 7x7 desenhado a partir do estado
    Battle                mensagens e botões de ação
    DPad                  controle direcional
```

## Do protótipo para o Svelte

| Protótipo (JS puro) | Svelte |
|---|---|
| `getElementById` + `textContent` | `{$player.hp}` direto no HTML |
| `updateHUD()` | desnecessário: a tela atualiza sozinha quando a store muda |
| `createMap()` a cada passo | `{#each}` em `MapGrid.svelte` |
| `classList.add("hidden")` | `{#if}` / `{:else if}` |
| variáveis globais (`player`, `currentEnemy`...) | stores em `lib/store.js` |

## Ajustes em relação ao protótipo

- As barras de HP/MP agora mudam de tamanho (antes ficavam sempre cheias).
- A caixa de mensagens aparece o tempo todo (antes só durante a batalha).
- O botão "VOLTAR AO MENU" aparece na tela do jogo (antes ficava sempre escondido).
- Os botões de ação ficam bloqueados durante o turno do inimigo, evitando cliques repetidos.
- Level up repete se o XP for suficiente para mais de um nível.
