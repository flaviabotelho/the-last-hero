<script>
  import { screen } from './lib/store.js';
  import Menu from './components/Menu.svelte';
  import About from './components/About.svelte';
  import Game from './components/Game.svelte';
</script>

<div class="game-container">
  {#if $screen === 'menu'}
    <Menu />
  {:else if $screen === 'about'}
    <About />
  {:else}
    <Game />
  {/if}
</div>
