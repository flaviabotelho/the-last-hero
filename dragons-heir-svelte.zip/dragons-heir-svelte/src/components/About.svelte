<script>
  import { backToMenu } from '../lib/store.js';
</script>

<section id="about-screen" class="screen">
  <h2 class="screen-title">DRAGON'S HEIR</h2>

  <div class="story-box">
    <h3>- A JORNADA -</h3>
    <p>O Reino de Alefgard está em trevas profundas.</p>
    <p>O terrível Dragão de Bronze roubou a Esfera de Luz...</p>
    <p>Você, o último descendente da linhagem do Guerreiro Lendário...</p>
  </div>

  <button type="button" class="menu-btn" on:click={backToMenu}>VOLTAR</button>
</section>
