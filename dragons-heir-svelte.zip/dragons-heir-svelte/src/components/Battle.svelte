<script>
  import { enemy, message, locked, attack, heal } from '../lib/store.js';
</script>

<div class="battle-box">
  <p>{$message}</p>
</div>

{#if $enemy}
  <div id="battle-actions" class="menu-options" style="gap: 8px; margin-bottom: 5px;">
    <button
      type="button"
      class="menu-btn"
      style="width: 200px; height: 38px;"
      disabled={$locked}
      on:click={attack}
    >
      ⚔️ ATACAR
    </button>

    <button
      type="button"
      class="menu-btn"
      style="width: 200px; height: 38px;"
      disabled={$locked}
      on:click={heal}
    >
      ✨ CURAR (-3 MP)
    </button>
  </div>
{/if}
