<script>
  import { movePlayer } from '../lib/store.js';
</script>

<div class="d-pad">
  <button type="button" class="pad-btn" on:click={() => movePlayer(0, -1)}>▲</button>

  <div class="d-pad-row">
    <button type="button" class="pad-btn" on:click={() => movePlayer(-1, 0)}>◀</button>
    <div class="d-pad-center">🧭</div>
    <button type="button" class="pad-btn" on:click={() => movePlayer(1, 0)}>▶</button>
  </div>

  <button type="button" class="pad-btn" on:click={() => movePlayer(0, 1)}>▼</button>
</div>
