<script>
  import { enemy } from '../lib/store.js';

  $: hpPct = $enemy ? ($enemy.hp / $enemy.maxHp) * 100 : 0;
</script>

<aside class="hud-side hud-enemy">
  {#if $enemy}
    <div class="enemy-hud hud-panel">
      <div class="hud-title enemy-title">☠️ INIMIGO</div>

      <div class="enemy-name"><strong>{$enemy.name}</strong></div>

      <div class="stat-row"><span>HP</span><strong>{$enemy.hp}</strong></div>
      <div class="bar"><div class="bar-fill enemy-hp-fill" style="width: {hpPct}%"></div></div>
    </div>
  {/if}
</aside>
