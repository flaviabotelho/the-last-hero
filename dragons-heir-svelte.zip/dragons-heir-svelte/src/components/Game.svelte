<script>
  import HeroHud from './HeroHud.svelte';
  import EnemyHud from './EnemyHud.svelte';
  import MapGrid from './MapGrid.svelte';
  import Battle from './Battle.svelte';
  import DPad from './DPad.svelte';
  import { movePlayer, attack, exitGame, enemy } from '../lib/store.js';

  function onKey(event) {
    switch (event.key) {
      case 'ArrowUp':
      case 'w':
      case 'W':
        event.preventDefault();
        movePlayer(0, -1);
        break;

      case 'ArrowDown':
      case 's':
      case 'S':
        event.preventDefault();
        movePlayer(0, 1);
        break;

      case 'ArrowLeft':
      case 'a':
      case 'A':
        event.preventDefault();
        movePlayer(-1, 0);
        break;

      case 'ArrowRight':
      case 'd':
      case 'D':
        event.preventDefault();
        movePlayer(1, 0);
        break;

      case 'Enter':
        if ($enemy) attack();
        break;
    }
  }
</script>

<svelte:window on:keydown={onKey} />

<section id="game-screen" class="screen">
  <div class="game-center">
    <div class="hud-layout">
      <HeroHud />

      <main class="map-area">
        <MapGrid />

        <div class="map-legend">
          <span>🧙 Herói</span>
          <span>👹 Inimigo</span>
          <span>🐉 Chefe</span>
          <span>🏠 Cura</span>
          <span>🪙 Gold</span>
        </div>
      </main>

      <EnemyHud />
    </div>

    <div class="battle-area">
      <Battle />
      <DPad />

      <button id="btn-game-exit" type="button" class="menu-btn" on:click={exitGame}>
        VOLTAR AO MENU
      </button>
    </div>
  </div>
</section>
