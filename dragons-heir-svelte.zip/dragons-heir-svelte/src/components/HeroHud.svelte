<script>
  import { player } from '../lib/store.js';

  $: hpPct = ($player.hp / $player.maxHp) * 100;
  $: mpPct = ($player.mp / $player.maxMp) * 100;
</script>

<aside class="hud-side hud-hero">
  <div class="player-hud hud-panel">
    <div class="hud-title">⚔️ HERÓI</div>
    <div class="player-name">HERDEIRO LENDÁRIO</div>

    <div class="stat-row"><span>LV</span><strong>{$player.level}</strong></div>

    <div class="stat-row"><span>HP</span><strong>{$player.hp}</strong></div>
    <div class="bar"><div class="bar-fill hp-fill" style="width: {hpPct}%"></div></div>

    <div class="stat-row"><span>MP</span><strong>{$player.mp}</strong></div>
    <div class="bar"><div class="bar-fill mp-fill" style="width: {mpPct}%"></div></div>

    <div class="gold-display">🪙 <strong>{$player.gold}</strong> GOLD</div>
  </div>
</aside>
