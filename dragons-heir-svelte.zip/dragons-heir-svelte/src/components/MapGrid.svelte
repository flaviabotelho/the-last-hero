<script>
  import { player, goldCollected, bossDefeated } from '../lib/store.js';
  import { MAP_DATA, MAP_WIDTH, MAP_HEIGHT, TILES, getTile } from '../lib/data.js';

  $: cells = buildCells($player, $goldCollected, $bossDefeated);

  function buildCells(p, goldTaken, bossDown) {
    const result = [];

    for (let y = 0; y < MAP_HEIGHT; y++) {
      for (let x = 0; x < MAP_WIDTH; x++) {
        const tile = getTile(x, y);
        let { cls, icon } = TILES[tile];

        if (tile === 'G' && goldTaken) icon = '';
        if (tile === 'B' && bossDown) icon = '🏆';

        if (x === p.x && y === p.y) {
          cls = 'player';
          icon = '🧙';
        }

        result.push({ key: `${x}-${y}`, cls, icon });
      }
    }

    return result;
  }
</script>

<div class="map-frame">
  <div class="map-grid">
    {#each cells as cell (cell.key)}
      <div class="map-cell {cell.cls}">{cell.icon}</div>
    {/each}
  </div>
</div>
