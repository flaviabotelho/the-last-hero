<script>
  import { startGame, openAbout } from '../lib/store.js';
</script>

<section id="menu-screen" class="screen">
  <h1 class="game-title">Dragon's Heir</h1>

  <nav class="menu-options">
    <button type="button" class="menu-btn" on:click={startGame}>INICIAR JOGO</button>
    <button type="button" class="menu-btn" on:click={openAbout}>SOBRE</button>
  </nav>
</section>
